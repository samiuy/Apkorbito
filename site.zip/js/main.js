// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyC7L1lLF5XIJ7-mTW8pFGjU2_YDITfMPAM",
  authDomain: "samit-dda7a.firebaseapp.com",
  databaseURL: "https://samit-dda7a-default-rtdb.firebaseio.com",
  projectId: "samit-dda7a",
  storageBucket: "samit-dda7a.firebasestorage.app",
  messagingSenderId: "630285292069",
  appId: "1:630285292069:web:8333daccc9d99f802825cc"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const database = firebase.database();
const appsRef = database.ref('apps');

// Global variables
let selectedVersion = '';
let selectedSize = '';
let selectedUrl = '#';
let currentAppId = null;
let currentAppData = null;
let allApps = [];
let countdownInterval;

// Toggle side menu
function toggleMenu() {
  const sideMenu = document.getElementById('sideMenu');
  const menuOverlay = document.getElementById('menuOverlay');
  if (sideMenu) sideMenu.classList.toggle('active');
  if (menuOverlay) menuOverlay.classList.toggle('active');
}

function toggleMenuClose() {
  const sideMenu = document.getElementById('sideMenu');
  const menuOverlay = document.getElementById('menuOverlay');
  if (sideMenu) sideMenu.classList.remove('active');
  if (menuOverlay) menuOverlay.classList.remove('active');
}

// Modal for screenshots
function openModal(imgSrc) {
  const modal = document.getElementById('imageModal');
  const modalImg = document.getElementById('modalImage');
  if (modal && modalImg) {
    modalImg.src = imgSrc;
    modal.classList.add('active');
  }
}

function closeModal() {
  const modal = document.getElementById('imageModal');
  if (modal) modal.classList.remove('active');
}

// Toggle MOD features
function toggleModFeatures(element) {
  element.classList.toggle('active');
  const content = element.nextElementSibling;
  if (content) content.classList.toggle('active');
}

// Load all apps from Firebase
function loadApps() {
  // Set timeout for Firebase
  const timeout = setTimeout(() => {
    const featuredFallback = document.getElementById('featuredFallback');
    const categoriesFallback = document.getElementById('categoriesFallback');
    if (featuredFallback) featuredFallback.innerHTML = '<p style="color: var(--gray-600);">Apps temporarily unavailable. Please try again later.</p>';
    if (categoriesFallback) categoriesFallback.innerHTML = '<p style="color: var(--gray-600);">Categories temporarily unavailable.</p>';
  }, 5000);

  appsRef.on('value', (snapshot) => {
    clearTimeout(timeout);
    const apps = snapshot.val();
    allApps = [];
    
    if (apps) {
      Object.keys(apps).forEach(key => {
        allApps.push({
          id: key,
          ...apps[key]
        });
      });
    }

    // Update all sections
    updateFeaturedApps();
    updateCategories();
    updateAllAppsGrid();
    updateGamesGrid();
    updateAllCategoriesGrid();
  }, (error) => {
    clearTimeout(timeout);
    const featuredFallback = document.getElementById('featuredFallback');
    const categoriesFallback = document.getElementById('categoriesFallback');
    if (featuredFallback) featuredFallback.innerHTML = '<p style="color: var(--gray-600);">Unable to load apps. Please refresh.</p>';
    if (categoriesFallback) categoriesFallback.innerHTML = '<p style="color: var(--gray-600);">Unable to load categories.</p>';
  });
}

// Update featured apps on home page
function updateFeaturedApps() {
  const grid = document.getElementById('featuredAppsGrid');
  if (!grid) return;
  
  if (!allApps.length) {
    grid.innerHTML = '<p style="text-align: center; color: var(--gray-600);">No apps available</p>';
    return;
  }

  // Show first 4 apps as featured
  const featured = allApps.slice(0, 4);
  grid.innerHTML = featured.map(app => createAppCard(app)).join('');
}

// Update categories on home page
function updateCategories() {
  const grid = document.getElementById('categoriesGrid');
  if (!grid) return;
  
  const categories = [...new Set(allApps.map(app => app.category))];
  
  if (!categories.length) {
    grid.innerHTML = '<p style="text-align: center; color: var(--gray-600);">No categories available</p>';
    return;
  }

  const categoryCounts = {};
  allApps.forEach(app => {
    categoryCounts[app.category] = (categoryCounts[app.category] || 0) + 1;
  });

  grid.innerHTML = categories.map(cat => `
    <a href="/categories/${cat.toLowerCase().replace(/\s+/g, '-')}.html" class="category-card">
      <div class="category-icon"><i class="fas ${getCategoryIcon(cat)}"></i></div>
      <h3 class="category-title">${cat}</h3>
      <span class="badge">${categoryCounts[cat] || 0} apps</span>
    </a>
  `).join('');
}

// Update all apps grid
function updateAllAppsGrid() {
  const grid = document.getElementById('allAppsGrid');
  if (!grid) return;
  
  if (!allApps.length) {
    grid.innerHTML = '<p style="text-align: center; color: var(--gray-600);">No apps available</p>';
    return;
  }
  grid.innerHTML = allApps.map(app => createAppCard(app)).join('');
}

// Update games grid
function updateGamesGrid() {
  const grid = document.getElementById('gamesGrid');
  if (!grid) return;
  
  const games = allApps.filter(app => app.category === 'Games');
  if (!games.length) {
    grid.innerHTML = '<p style="text-align: center; color: var(--gray-600);">No games available</p>';
    return;
  }
  grid.innerHTML = games.map(app => createAppCard(app)).join('');
}

// Update all categories grid
function updateAllCategoriesGrid() {
  const grid = document.getElementById('allCategoriesGrid');
  if (!grid) return;
  
  const categories = [...new Set(allApps.map(app => app.category))];
  
  if (!categories.length) {
    grid.innerHTML = '<p style="text-align: center; color: var(--gray-600);">No categories available</p>';
    return;
  }

  const categoryCounts = {};
  allApps.forEach(app => {
    categoryCounts[app.category] = (categoryCounts[app.category] || 0) + 1;
  });

  grid.innerHTML = categories.map(cat => `
    <a href="/categories/${cat.toLowerCase().replace(/\s+/g, '-')}.html" class="category-card">
      <div class="category-icon"><i class="fas ${getCategoryIcon(cat)}"></i></div>
      <h3 class="category-title">${cat}</h3>
      <span class="badge">${categoryCounts[cat] || 0} apps</span>
    </a>
  `).join('');
}

// Get category icon
function getCategoryIcon(category) {
  const icons = {
    'Video Editors': 'fa-video',
    'Games': 'fa-gamepad',
    'Social Apps': 'fa-users',
    'Tools': 'fa-wrench'
  };
  return icons[category] || 'fa-folder';
}

// Create app card HTML
function createAppCard(app) {
  const typeBadge = app.type === 'mod' ? '<span class="badge badge-mod">MOD</span>' : '<span class="badge">App</span>';
  
  // Check if icon is URL or Font Awesome
  const isUrl = app.icon && app.icon.startsWith('http');
  const iconHtml = isUrl ? 
    `<img src="${app.icon}" alt="icon" onerror="this.src='https://via.placeholder.com/70?text=Icon'">` : 
    `<i class="fas ${app.icon || 'fa-video'}"></i>`;
  
  return `
    <a href="/apps/${app.id}.html" class="app-card">
      <div class="app-icon">${iconHtml}</div>
      <h3>${app.name}</h3>
      <div class="app-meta">
        ${typeBadge}
        <span class="version-badge">${app.version || 'v1.0'}</span>
      </div>
      <p style="color: var(--gray-600); margin: 0.8rem 0;">${app.description ? app.description.substring(0, 40) + '...' : ''}</p>
      <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
        <span style="background: var(--gray-100); padding: 0.2rem 0.8rem; border-radius: 50px; font-size: 0.8rem;">${app.size || '0 MB'}</span>
      </div>
    </a>
  `;
}

// Search apps
function searchApps() {
  const searchInput = document.getElementById('searchInput');
  const resultsGrid = document.getElementById('resultsGrid');
  const noResults = document.getElementById('noResults');
  const featuredApps = document.getElementById('featuredApps');
  const searchResults = document.getElementById('searchResults');
  
  if (!searchInput || !resultsGrid || !noResults || !featuredApps || !searchResults) return;
  
  const query = searchInput.value.toLowerCase().trim();
  
  if (query === '') {
    searchResults.style.display = 'none';
    featuredApps.style.display = 'block';
    return;
  }
  
  const results = allApps.filter(app => 
    app.name.toLowerCase().includes(query) || 
    (app.category && app.category.toLowerCase().includes(query))
  );
  
  resultsGrid.innerHTML = '';
  if (results.length > 0) {
    resultsGrid.innerHTML = results.map(app => createAppCard(app)).join('');
    noResults.style.display = 'none';
  } else {
    noResults.style.display = 'block';
  }
  
  searchResults.style.display = 'block';
  featuredApps.style.display = 'none';
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  loadApps();
  
  // Close menu when clicking on overlay
  const menuOverlay = document.getElementById('menuOverlay');
  if (menuOverlay) {
    menuOverlay.addEventListener('click', toggleMenu);
  }
});